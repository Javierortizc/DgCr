<!DOCTYPE html>
<html lang="es-ES">
<head>
<meta charset="UTF-8" />
<title>Guillermo Ortiz</title>
<!-- Created by Artisteer v4.1.0.59861 -->
<meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">
<!--[if lt IE 9]><script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

<link rel="stylesheet" href="style.css" media="screen" />
<!--link rel="pingback" href="http://www.magisterinformaticamedica.cl/xmlrpc.php" /-->
<!--link rel="alternate" type="application/rss+xml" title="MIM &raquo; Feed" href="http://www.magisterinformaticamedica.cl/feed/" /-->
<!--link rel="alternate" type="application/rss+xml" title="MIM &raquo; RSS de los comentarios" href="http://www.magisterinformaticamedica.cl/comments/feed/" /-->
		<!--script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/www.magisterinformaticamedica.cl\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.5.3"}};
			!function(a,b,c){function d(a){var c,d,e,f=b.createElement("canvas"),g=f.getContext&&f.getContext("2d"),h=String.fromCharCode;if(!g||!g.fillText)return!1;switch(g.textBaseline="top",g.font="600 32px Arial",a){case"flag":return g.fillText(h(55356,56806,55356,56826),0,0),f.toDataURL().length>3e3;case"diversity":return g.fillText(h(55356,57221),0,0),c=g.getImageData(16,16,1,1).data,d=c[0]+","+c[1]+","+c[2]+","+c[3],g.fillText(h(55356,57221,55356,57343),0,0),c=g.getImageData(16,16,1,1).data,e=c[0]+","+c[1]+","+c[2]+","+c[3],d!==e;case"simple":return g.fillText(h(55357,56835),0,0),0!==g.getImageData(16,16,1,1).data[0];case"unicode8":return g.fillText(h(55356,57135),0,0),0!==g.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script-->
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wpfb-css'  href='//www.magisterinformaticamedica.cl/wp-content/plugins/wp-filebase/wp-filebase.css?t=1461827559&#038;ver=3.4.4' type='text/css' media='all' />
<link rel='stylesheet' id='bbp-default-css'  href='http://www.magisterinformaticamedica.cl/wp-content/plugins/bbpress/templates/default/css/bbpress.css?ver=2.5.9-6017' type='text/css' media='screen' />
<!--[if lte IE 7]>
<link rel='stylesheet' id='style.ie7.css-css'  href='http://www.magisterinformaticamedica.cl/wp-content/themes/MIM2014V3/style.ie7.css?ver=4.5.3' type='text/css' media='screen' />
<![endif]-->
<!--link rel='stylesheet' id='style.responsive.css-css'  href='http://www.magisterinformaticamedica.cl/wp-content/themes/MIM2014V3/style.responsive.css?ver=4.5.3' type='text/css' media='all' /-->
<!--link rel='stylesheet' id='wp-members-css'  href='http://www.magisterinformaticamedica.cl/wp-content/plugins/wp-members/css/wp-members-kubrick.css?ver=3.1.2' type='text/css' media='all' /-->
<!--script type='text/javascript' src='http://www.magisterinformaticamedica.cl/wp-content/themes/MIM2014V3/script.js?ver=4.5.3'></script-->
<!--script type='text/javascript' src='http://www.magisterinformaticamedica.cl/wp-content/themes/MIM2014V3/script.responsive.js?ver=4.5.3'></script-->
<!--link rel='https://api.w.org/' href='http://www.magisterinformaticamedica.cl/wp-json/' /-->
<!--link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://www.magisterinformaticamedica.cl/xmlrpc.php?rsd" /-->
<!--link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://www.magisterinformaticamedica.cl/wp-includes/wlwmanifest.xml" /-->
<!--link rel="canonical" href="http://www.magisterinformaticamedica.cl/" /-->
<!--link rel='shortlink' href='http://www.magisterinformaticamedica.cl/' /-->
<!--link rel="alternate" type="application/json+oembed" href="http://www.magisterinformaticamedica.cl/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwww.magisterinformaticamedica.cl%2F" /-->
<!--link rel="alternate" type="text/xml+oembed" href="http://www.magisterinformaticamedica.cl/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwww.magisterinformaticamedica.cl%2F&#038;format=xml" /-->
<!--link rel='header_link' href='http://www.magisterinformaticamedica.cl/' />		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style-->

<script type="text/javascript">
function showResult(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("livesearch").innerHTML= xmlhttp.responseText;
    }
  }
  xmlhttp.open("POST","query.php",true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8");
  xmlhttp.send("q="+str+"|");
}
</script>

<script type="text/javascript">
function consultaPausada(str) {
	if (typeof window.timestamp === 'undefined') {
		window.timestamp = Date.now();
	} ;
	if (window.timestamp-Date.now() > 300) {
			showResult(str);
			window.timestamp = Date.now();
		}
	}
</script>

</head>
<body class="home page page-id-150 page-template-default">

<div id="art-main">
    <div class="art-sheet clearfix">

<header class="art-header clickable">
<div class="art-shapes"></div>

</header>
<div class="art-layout-wrapper">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
<div class="art-layout-cell art-content"><article id="post-150"  class="art-post art-article  post-150 page type-page status-publish hentry">
<div class="art-postcontent clearfix"><h3 style="text-align: center;"><span style="font-family: 'arial black', sans-serif; font-size: 18pt;">Detector de Patología Crítica en Informes Radiológicos<br />
</span></h3>
<h3 style="text-align: center;">Demostración para grado de magíster en informática médica<br/>de la Universidad de Chile.</h3>
<div class="page" title="Page 7">
<div class="layoutArea">
</div>
</div>
<div class="page" title="Page 7"></div>
<hr />
<form>
<p><strong>Ingrese un informe en el area para procesar:</strong></p>
<textarea id="informe" align="center" rows="10" style="width:100%" onkeyup="showResult(this.value)">
</textarea>
</form>
<div style="padding-top:10px;">
<hr />

<div id="livesearch"></div>

<!-- ACA SE DESPLIEGA LA INFO DE VUELTA-->

</div>
</article>


                        </div>
                    </div>
                </div>
            </div><footer class="art-footer"><div class="art-footer-text">
<img src="http://www.magisterinformaticamedica.cl/wp-content/uploads/2015/09/footer_mim_5.png"/>
</div>
</footer>

    </div>
</div>


<div id="wp-footer">
</div>


</body>
</html>
